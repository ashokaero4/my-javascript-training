import React, { Component} from "react";

class Counter extends Component{
    constructor(props){
        super(props);
        this.state= {
            count:0 
        }
    }

    increment =()=>{
        this.setState({
            count: this.state.count + 1
        });
    }

    decrement =()=>{
        this.setState({
            count: this.state.count - 1
        });
    }

    Styles = {
         fontSize:20
    }

    render(){
        return (
          <div> 
                
                <button style={ this.Styles } onClick={this.increment}> click me for Incre!</button>
                <h3>this is our counter operation : {this.state.count}</h3>
                <button  style={ this.Styles } onClick={this.decrement}>click me for Decre!</button>
               
          </div>
        );
    }
}

export default Counter;