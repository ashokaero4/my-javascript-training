import React, { Component} from "react";
import Counter from "./counter";
import './index.css';


class App extends Component {
  render(){
  return (
    <div className="App"> 
          <h1>counter app</h1>
          <Counter/>
          


    </div>
     
  );
  }
}

export default App;
